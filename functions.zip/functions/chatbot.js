// functions/chatbot.js

const { GoogleGenerativeAI } = require('@google/generative-ai');
const admin = require('firebase-admin');
const chatbotConfig = require('./chatbot-config');

/**
 * Get current plant data for context
 */
async function getCurrentPlantData() {
  try {
    const snapshot = await admin.database()
      .ref('cement_plant_data/current')
      .once('value');
    return snapshot.val();
  } catch (error) {
    console.error('Error fetching plant data:', error);
    return null;
  }
}

/**
 * Get recent alerts for context
 */
async function getRecentAlerts() {
  try {
    const snapshot = await admin.database()
      .ref('cement_plant_data/alerts')
      .orderByChild('timestamp')
      .limitToLast(5)
      .once('value');
    
    const alerts = [];
    snapshot.forEach(child => {
      alerts.push(child.val());
    });
    return alerts;
  } catch (error) {
    console.error('Error fetching alerts:', error);
    return [];
  }
}

/**
 * Format plant data for AI context
 */
function formatPlantDataForAI(plantData, alerts) {
  if (!plantData) {
    return "Current plant data is unavailable.";
  }

  let context = "Current Plant Status:\n";
  context += `- Clinker Inlet Temp: ${plantData.Clinker_Inlet_Temp?.toFixed(1)}°C\n`;
  context += `- Clinker Outlet Temp: ${plantData.Clinker_Outlet_Temp?.toFixed(1)}°C\n`;
  context += `- Cooling Air Flow: ${plantData.Cooling_Air_Flow?.toFixed(1)} m³/min\n`;
  context += `- Secondary Air Temp: ${plantData.Secondary_Air_Temp_Cooler?.toFixed(1)}°C\n`;
  context += `- Grate Speed: ${plantData.Grate_Speed?.toFixed(1)} rpm\n`;
  context += `- Clinker Production: ${plantData.Clinker_Production_Rate?.toFixed(1)} t/h\n`;
  context += `- Cement Mill Feed Rate: ${plantData.Cement_Mill_Feed_Rate?.toFixed(1)} t/h\n`;
  context += `- Gypsum Addition: ${plantData.Gypsum_Addition?.toFixed(2)}%\n`;
  context += `- Cement Mill Power: ${plantData.Cement_Mill_Power?.toFixed(0)} kW\n`;
  context += `- Cement Fineness (Blaine): ${plantData.Cement_Fineness_Blaine?.toFixed(0)} cm²/g\n`;
  context += `- Cement Fineness (45μm): ${plantData.Cement_Fineness_45um?.toFixed(1)}%\n`;
  context += `- Separator Efficiency: ${plantData.Separator_Efficiency?.toFixed(1)}%\n`;
  context += `- Last Updated: ${new Date(plantData.timestamp).toLocaleString()}\n`;

  if (alerts && alerts.length > 0) {
    context += "\nRecent Alerts:\n";
    alerts.forEach((alert, i) => {
      if (alert.alerts) {
        alert.alerts.forEach(a => {
          context += `- ${a.parameter}: ${a.message}\n`;
        });
      }
    });
  }

  return context;
}

/**
 * Generate AI response using Gemini
 */
async function generateAIResponse(userMessage, plantData, alerts, apiKey) {
  try {
    const genAI = new GoogleGenerativeAI(apiKey);
    const model = genAI.getGenerativeModel({ model: "gemini-pro" });

    // Prepare context
    const plantContext = formatPlantDataForAI(plantData, alerts);
    
    // Combine system prompt, current data, and user question
    const prompt = `${chatbotConfig.systemPrompt}

${plantContext}

User Question: ${userMessage}

Provide a helpful, concise response based on the current plant data and your expertise in cement manufacturing:`;

    // Generate response
    const result = await model.generateContent(prompt);
    const response = await result.response;
    const text = response.text();

    return {
      success: true,
      response: text,
      timestamp: new Date().toISOString()
    };

  } catch (error) {
    console.error('Error generating AI response:', error);
    return {
      success: false,
      error: error.message,
      response: "I'm having trouble processing your question right now. Please try again in a moment."
    };
  }
}

/**
 * Save chat history
 */
async function saveChatHistory(userId, userMessage, aiResponse) {
  try {
    await admin.database()
      .ref('chat_history')
      .push({
        userId: userId || 'anonymous',
        userMessage,
        aiResponse: aiResponse.response,
        timestamp: admin.database.ServerValue.TIMESTAMP,
        success: aiResponse.success
      });
  } catch (error) {
    console.error('Error saving chat history:', error);
  }
}

module.exports = {
  getCurrentPlantData,
  getRecentAlerts,
  generateAIResponse,
  saveChatHistory,
  formatPlantDataForAI
};

