
// Alert configuration
module.exports = {
  // Alert thresholds
  thresholds: {
    Clinker_Outlet_Temp: {
      min: 60,
      max: 150,
      enabled: true
    },
    Clinker_Inlet_Temp: {
      min: 1200,
      max: 1400,
      enabled: true
    },
    Cooling_Air_Flow: {
      min: 400,
      max: 600,
      enabled: true
    },
    Secondary_Air_Temp_Cooler: {
      min: 800,
      max: 1000,
      enabled: true
    },
    Clinker_Production_Rate: {
      min: 100,
      max: 160,
      enabled: true
    }
  },
  
  // Alert recipients
  phoneNumbers: [
    '+918930790886',  // Replace with your actual number
    '+918569803950'   // Add more numbers as needed
  ],
  
  // Twilio configuration (set these as environment variables)
  twilio: {
    accountSid: process.env.TWILIO_ACCOUNT_SID,
    authToken: process.env.TWILIO_AUTH_TOKEN,
    phoneNumber: process.env.TWILIO_PHONE_NUMBER
  },
  
  // Alert cooldown (minutes) - prevent repeated calls
  cooldownMinutes: 10,
  
  // Message templates
  messages: {
    Clinker_Outlet_Temp: 'Alert! Clinker outlet temperature is {value} degrees Celsius, which is outside the safe range of {min} to {max} degrees. Immediate action required.',
    Clinker_Inlet_Temp: 'Alert! Clinker inlet temperature is {value} degrees Celsius, which is outside the safe range of {min} to {max} degrees. Please check the system.',
    Cooling_Air_Flow: 'Alert! Cooling air flow is {value} cubic meters per minute, which is outside the safe range of {min} to {max}. Check cooling system.',
    Secondary_Air_Temp_Cooler: 'Alert! Secondary air temperature is {value} degrees Celsius, which is outside the safe range of {min} to {max} degrees.',
    Clinker_Production_Rate: 'Alert! Clinker production rate is {value} tons per hour, which is outside the safe range of {min} to {max}.'
  }
};

