// /**
//  * Import function triggers from their respective submodules:
//  *
//  * const {onCall} = require("firebase-functions/v2/https");
//  * const {onDocumentWritten} = require("firebase-functions/v2/firestore");
//  *
//  * See a full list of supported triggers at https://firebase.google.com/docs/functions
//  */

// const {setGlobalOptions} = require("firebase-functions");
// const {onRequest} = require("firebase-functions/https");
// const logger = require("firebase-functions/logger");

// // For cost control, you can set the maximum number of containers that can be
// // running at the same time. This helps mitigate the impact of unexpected
// // traffic spikes by instead downgrading performance. This limit is a
// // per-function limit. You can override the limit for each function using the
// // `maxInstances` option in the function's options, e.g.
// // `onRequest({ maxInstances: 5 }, (req, res) => { ... })`.
// // NOTE: setGlobalOptions does not apply to functions using the v1 API. V1
// // functions should each use functions.runWith({ maxInstances: 10 }) instead.
// // In the v1 API, each function can only serve one request per container, so
// // this will be the maximum concurrent request count.
// setGlobalOptions({ maxInstances: 10 });

// // Create and deploy your first functions
// // https://firebase.google.com/docs/functions/get-started

// // exports.helloWorld = onRequest((request, response) => {
// //   logger.info("Hello logs!", {structuredData: true});
// //   response.send("Hello from Firebase!");
// // });

const functions = require('firebase-functions');
const admin = require('firebase-admin');
const twilio = require('twilio');
const alertConfig = require('./alert-config');

admin.initializeApp();

// Initialize Twilio client
const twilioClient = twilio(
  alertConfig.twilio.accountSid,
  alertConfig.twilio.authToken
);

// Store last alert times to prevent spam
const lastAlertTimes = {};

/**
 * Check if alert cooldown period has passed
 */
function canSendAlert(parameterName) {
  const now = Date.now();
  const lastAlertTime = lastAlertTimes[parameterName] || 0;
  const cooldownMs = alertConfig.cooldownMinutes * 60 * 1000;
  
  return (now - lastAlertTime) > cooldownMs;
}

/**
 * Update last alert time
 */
function updateLastAlertTime(parameterName) {
  lastAlertTimes[parameterName] = Date.now();
}

/**
 * Make phone call using Twilio
 */
async function makePhoneCall(phoneNumber, message) {
  try {
    // Create TwiML for voice call
    const twiml = `
      <Response>
        <Say voice="alice" language="en-IN">
          ${message}
        </Say>
        <Pause length="1"/>
        <Say voice="alice" language="en-IN">
          I repeat. ${message}
        </Say>
      </Response>
    `;
    
    const call = await twilioClient.calls.create({
      twiml: twiml,
      to: phoneNumber,
      from: alertConfig.twilio.phoneNumber,
      timeout: 30
    });
    
    console.log(`✅ Call initiated to ${phoneNumber}. SID: ${call.sid}`);
    return call;
  } catch (error) {
    console.error(`❌ Failed to call ${phoneNumber}:`, error);
    throw error;
  }
}

/**
 * Send SMS as backup (optional)
 */
async function sendSMS(phoneNumber, message) {
  try {
    const sms = await twilioClient.messages.create({
      body: message,
      to: phoneNumber,
      from: alertConfig.twilio.phoneNumber
    });
    
    console.log(`✅ SMS sent to ${phoneNumber}. SID: ${sms.sid}`);
    return sms;
  } catch (error) {
    console.error(`❌ Failed to send SMS to ${phoneNumber}:`, error);
    throw error;
  }
}

/**
 * Check if value is outside threshold
 */
function isOutsideThreshold(parameter, value) {
  const threshold = alertConfig.thresholds[parameter];
  
  if (!threshold || !threshold.enabled) {
    return false;
  }
  
  return value < threshold.min || value > threshold.max;
}

/**
 * Generate alert message
 */
function generateMessage(parameter, value) {
  const threshold = alertConfig.thresholds[parameter];
  const template = alertConfig.messages[parameter] || 
    `Alert! ${parameter} is ${value}, which is outside safe range.`;
  
  return template
    .replace('{value}', value.toFixed(1))
    .replace('{min}', threshold.min)
    .replace('{max}', threshold.max);
}

/**
 * Firebase Function: Monitor data changes and trigger alerts
 */
exports.monitorCementPlantData = functions.database
  .ref('/cement_plant_data/current')
  .onUpdate(async (change, context) => {
    const newData = change.after.val();
    const oldData = change.before.val();
    
    console.log('📊 Data update detected:', newData.timestamp);
    
    const alerts = [];
    
    // Check each parameter
    for (const [parameter, value] of Object.entries(newData)) {
      // Skip non-numeric parameters
      if (typeof value !== 'number') continue;
      
      // Check if threshold is violated
      if (isOutsideThreshold(parameter, value)) {
        // Check cooldown period
        if (!canSendAlert(parameter)) {
          console.log(`⏳ Alert cooldown active for ${parameter}`);
          continue;
        }
        
        console.log(`🚨 ALERT: ${parameter} = ${value}`);
        
        // Generate message
        const message = generateMessage(parameter, value);
        
        // Store alert info
        alerts.push({
          parameter,
          value,
          message,
          timestamp: new Date().toISOString()
        });
        
        // Update cooldown
        updateLastAlertTime(parameter);
        
        // Make calls to all configured numbers
        const callPromises = alertConfig.phoneNumbers.map(phoneNumber => 
          makePhoneCall(phoneNumber, message)
            .catch(error => console.error(`Failed to call ${phoneNumber}:`, error))
        );
        
        // Also send SMS as backup
        const smsPromises = alertConfig.phoneNumbers.map(phoneNumber => 
          sendSMS(phoneNumber, message)
            .catch(error => console.error(`Failed to SMS ${phoneNumber}:`, error))
        );
        
        await Promise.allSettled([...callPromises, ...smsPromises]);
      }
    }
    
    // Log alerts to database
    if (alerts.length > 0) {
      await admin.database()
        .ref('cement_plant_data/alerts')
        .push({
          alerts: alerts,
          timestamp: admin.database.ServerValue.TIMESTAMP
        });
    }
    
    return null;
  });

/**
 * HTTP Function: Test alert system
 */
exports.testAlert = functions.https.onRequest(async (req, res) => {
  try {
    const testMessage = 'This is a test alert from the Cement Plant monitoring system. If you receive this call, the alert system is working correctly.';
    
    const results = await Promise.allSettled(
      alertConfig.phoneNumbers.map(phoneNumber => 
        makePhoneCall(phoneNumber, testMessage)
      )
    );
    
    res.json({
      success: true,
      message: 'Test alerts sent',
      results: results.map((r, i) => ({
        phoneNumber: alertConfig.phoneNumbers[i],
        status: r.status,
        callSid: r.value?.sid
      }))
    });
  } catch (error) {
    console.error('Test alert failed:', error);
    res.status(500).json({ error: error.message });
  }
});

/**
 * HTTP Function: Update alert configuration
 */
exports.updateAlertConfig = functions.https.onRequest(async (req, res) => {
  // Add authentication here in production
  
  const { parameter, min, max, enabled } = req.body;
  
  if (!parameter || !alertConfig.thresholds[parameter]) {
    return res.status(400).json({ error: 'Invalid parameter' });
  }
  
  // Update configuration in database
  await admin.database()
    .ref(`alert_config/thresholds/${parameter}`)
    .set({
      min: min !== undefined ? min : alertConfig.thresholds[parameter].min,
      max: max !== undefined ? max : alertConfig.thresholds[parameter].max,
      enabled: enabled !== undefined ? enabled : alertConfig.thresholds[parameter].enabled
    });
  
  res.json({ success: true, message: 'Alert configuration updated' });
});

/**
 * Scheduled Function: Daily alert system health check
 */
exports.dailyHealthCheck = functions.pubsub
  .schedule('0 9 * * *')  // 9 AM daily
  .timeZone('Asia/Kolkata')
  .onRun(async (context) => {
    console.log('🏥 Running daily health check...');
    
    // Check if alerts are functioning
    const recentAlerts = await admin.database()
      .ref('cement_plant_data/alerts')
      .orderByChild('timestamp')
      .limitToLast(10)
      .once('value');
    
    console.log(`Recent alerts count: ${recentAlerts.numChildren()}`);
    
    return null;
  });


// ========================================
// CHATBOT FUNCTIONS
// ========================================

const chatbot = require('./chatbot');
const chatbotConfig = require('./chatbot-config');

/**
 * HTTP Function: Chat endpoint
 */
exports.chat = functions.https.onRequest(async (req, res) => {
  // Enable CORS
  res.set('Access-Control-Allow-Origin', '*');
  res.set('Access-Control-Allow-Methods', 'POST, OPTIONS');
  res.set('Access-Control-Allow-Headers', 'Content-Type');

  // Handle preflight
  if (req.method === 'OPTIONS') {
    return res.status(204).send('');
  }

  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  try {
    const { message, userId } = req.body;

    if (!message || typeof message !== 'string') {
      return res.status(400).json({ error: 'Message is required' });
    }

    console.log(`📨 Chat request from ${userId || 'anonymous'}: ${message}`);

    // Get current plant data and alerts
    const [plantData, alerts] = await Promise.all([
      chatbot.getCurrentPlantData(),
      chatbot.getRecentAlerts()
    ]);

    // Get Gemini API key from environment
    const geminiApiKey = functions.config().gemini?.api_key;
    
    if (!geminiApiKey) {
      throw new Error('Gemini API key not configured');
    }

    // Generate AI response
    const aiResponse = await chatbot.generateAIResponse(
      message,
      plantData,
      alerts,
      geminiApiKey
    );

    // Save to history
    await chatbot.saveChatHistory(userId, message, aiResponse);

    console.log(`✅ Chat response generated successfully`);

    return res.json({
      success: true,
      response: aiResponse.response,
      timestamp: aiResponse.timestamp,
      currentData: plantData
    });

  } catch (error) {
    console.error('❌ Chat error:', error);
    return res.status(500).json({
      success: false,
      error: error.message,
      response: "I apologize, but I'm experiencing technical difficulties. Please try again."
    });
  }
});

/**
 * HTTP Function: Get sample questions
 */
exports.getChatSuggestions = functions.https.onRequest((req, res) => {
  res.set('Access-Control-Allow-Origin', '*');
  
  res.json({
    success: true,
    suggestions: chatbotConfig.sampleQuestions
  });
});

/**
 * HTTP Function: Get chat history
 */
exports.getChatHistory = functions.https.onRequest(async (req, res) => {
  res.set('Access-Control-Allow-Origin', '*');
  
  try {
    const userId = req.query.userId || 'anonymous';
    const limit = parseInt(req.query.limit) || 20;

    const snapshot = await admin.database()
      .ref('chat_history')
      .orderByChild('userId')
      .equalTo(userId)
      .limitToLast(limit)
      .once('value');

    const history = [];
    snapshot.forEach(child => {
      history.push({ id: child.key, ...child.val() });
    });

    res.json({
      success: true,
      history: history.reverse()
    });

  } catch (error) {
    console.error('Error fetching chat history:', error);
    res.status(500).json({ error: error.message });
  }
});


