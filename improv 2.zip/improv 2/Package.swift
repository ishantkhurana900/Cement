// swift-tools-version:5.9
import PackageDescription

let package = Package(
    name: "Improv",
    platforms: [
        .macOS(.v14)
    ],
    targets: [
        .executableTarget(
            name: "Improv",
            path: "Sources/Improv"
        )
    ]
)
