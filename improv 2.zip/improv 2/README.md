# Improv

A tiny macOS **menu-bar app** that improves selected text anywhere on your Mac with one shortcut.

Draft rough text (an email, a message), **select it**, press the hotkey, review the AI's
rewrite in a small popup, and hit **Accept** to drop it back in place.

## How it works

1. You press the global hotkey (default **⌥⌘I**) with text selected.
2. Improv copies the selection, sends it to an OpenAI-compatible API to rewrite for grammar,
   clarity, structure, and tone.
3. A preview window shows the improved text (editable). **Accept & Replace** pastes it over
   your selection; your original clipboard is restored automatically.

## Build & run

Requires Xcode's Swift toolchain (no Homebrew or third-party packages needed).

```bash
./build.sh            # builds Improv.app (release) and ad-hoc signs it
open Improv.app       # launches it into the menu bar
```

For quick iteration you can also `swift build && swift run`, but the menu-bar behaviour and
Accessibility permission work best from the bundled `Improv.app`.

## First-time setup

1. **Grant Accessibility access.** On first run macOS prompts you — enable **Improv** under
   *System Settings → Privacy & Security → Accessibility*. This is required for the copy/paste
   automation. (Re-enable it after a rebuild if it gets reset, since the ad-hoc signature changes.)
2. Open the menu-bar icon → **Settings…** and set:
   - **API Base URL** — e.g. `https://api.openai.com/v1` (or your own compatible endpoint).
   - **Model** — e.g. `gpt-4o-mini`.
   - **API Key** — stored in your macOS Keychain.
   - **Tone** and the **shortcut**, if you want to change them.

## Project layout

| File | Purpose |
|------|---------|
| `Package.swift` | SwiftPM manifest (executable target, macOS 14+). |
| `Sources/Improv/ImprovApp.swift` | App entry, `MenuBarExtra`, delegate wiring. |
| `Sources/Improv/AppState.swift` | Settings + the improve-flow orchestration. |
| `Sources/Improv/TextCapture.swift` | ⌘C capture / ⌘V replace, clipboard preservation. |
| `Sources/Improv/AIClient.swift` | OpenAI-compatible `/chat/completions` call. |
| `Sources/Improv/HotkeyManager.swift` | Global hotkey via Carbon + key-combo model. |
| `Sources/Improv/PreviewWindow.swift` | The accept/edit/regenerate popup. |
| `Sources/Improv/SettingsView.swift` | Settings UI + hotkey recorder. |
| `Sources/Improv/Keychain.swift` | API-key storage. |
| `Resources/Info.plist` | Bundle plist (`LSUIElement`, usage strings). |
| `build.sh` | Builds and packages `Improv.app`. |

## Notes

- The app is **not sandboxed** on purpose — Accessibility control and synthetic key events
  don't work under the App Sandbox.
- The AI endpoint is fully configurable, so switching providers later is just changing the
  Base URL / Model / Key fields.
