#!/bin/bash
# Builds Improv and wraps it into a runnable Improv.app bundle.
set -euo pipefail

cd "$(dirname "$0")"

CONFIG="${1:-release}"
APP="Improv.app"
CONTENTS="$APP/Contents"

echo "▶ Building ($CONFIG)…"
swift build -c "$CONFIG"

BIN_PATH="$(swift build -c "$CONFIG" --show-bin-path)/Improv"
if [[ ! -f "$BIN_PATH" ]]; then
  echo "✗ Build product not found at $BIN_PATH" >&2
  exit 1
fi

echo "▶ Assembling $APP…"
rm -rf "$APP"
mkdir -p "$CONTENTS/MacOS" "$CONTENTS/Resources"
cp "$BIN_PATH" "$CONTENTS/MacOS/Improv"
cp Resources/Info.plist "$CONTENTS/Info.plist"
printf 'APPL????' > "$CONTENTS/PkgInfo"

echo "▶ Signing (ad-hoc)…"
codesign --force --deep --sign - "$APP"

echo "✓ Built $APP"
echo "  Run it with:  open $APP"
