import AppKit
import Carbon.HIToolbox

/// Captures the current selection (via ⌘C) and replaces it (via ⌘V), preserving
/// the user's existing clipboard contents across both operations.
enum TextCapture {
    /// The app that was frontmost when we captured — we re-activate it before pasting.
    private static var targetApp: NSRunningApplication?

    /// Copies the current selection and returns it, restoring the prior clipboard.
    /// Returns nil if nothing was copied (e.g. no selection).
    static func captureSelection() -> String? {
        let pb = NSPasteboard.general
        targetApp = NSWorkspace.shared.frontmostApplication

        let saved = snapshot(pb)
        let before = pb.changeCount

        postKey(kVK_ANSI_C)

        // Wait (briefly) for the pasteboard to receive the copied text.
        let deadline = Date().addingTimeInterval(0.5)
        while pb.changeCount == before && Date() < deadline {
            RunLoop.current.run(mode: .default, before: Date().addingTimeInterval(0.02))
        }

        let copied: String? = (pb.changeCount != before) ? pb.string(forType: .string) : nil
        restore(saved, to: pb)
        return copied
    }

    /// Puts `text` on the clipboard, re-activates the original app, pastes, then
    /// restores the previous clipboard contents.
    static func replaceSelection(with text: String) {
        let pb = NSPasteboard.general
        let saved = snapshot(pb)

        pb.clearContents()
        pb.setString(text, forType: .string)

        // Return focus to wherever the text came from before pasting.
        targetApp?.activate()

        DispatchQueue.main.asyncAfter(deadline: .now() + 0.15) {
            postKey(kVK_ANSI_V)
            // Restore the user's original clipboard after the paste lands.
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.3) {
                restore(saved, to: pb)
            }
        }
    }

    // MARK: - Keystroke synthesis

    private static func postKey(_ keyCode: Int) {
        let src = CGEventSource(stateID: .combinedSessionState)
        let down = CGEvent(keyboardEventSource: src, virtualKey: CGKeyCode(keyCode), keyDown: true)
        let up   = CGEvent(keyboardEventSource: src, virtualKey: CGKeyCode(keyCode), keyDown: false)
        down?.flags = .maskCommand
        up?.flags = .maskCommand
        down?.post(tap: .cghidEventTap)
        up?.post(tap: .cghidEventTap)
    }

    // MARK: - Clipboard snapshot / restore

    private static func snapshot(_ pb: NSPasteboard) -> [String: Data] {
        var dict: [String: Data] = [:]
        for item in pb.pasteboardItems ?? [] {
            for type in item.types {
                if let data = item.data(forType: type) {
                    dict[type.rawValue] = data
                }
            }
        }
        return dict
    }

    private static func restore(_ snap: [String: Data], to pb: NSPasteboard) {
        pb.clearContents()
        guard !snap.isEmpty else { return }
        let item = NSPasteboardItem()
        for (type, data) in snap {
            item.setData(data, forType: NSPasteboard.PasteboardType(type))
        }
        pb.writeObjects([item])
    }
}
