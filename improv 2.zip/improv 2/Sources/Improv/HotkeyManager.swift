import AppKit
import Carbon.HIToolbox

/// A global hotkey combination (Carbon virtual key code + Carbon modifier mask).
struct HotkeyCombo: Equatable {
    var keyCode: UInt32
    var carbonModifiers: UInt32

    static let `default` = HotkeyCombo(
        keyCode: UInt32(kVK_ANSI_I),
        carbonModifiers: UInt32(cmdKey | optionKey)
    )

    var displayString: String {
        var s = ""
        if carbonModifiers & UInt32(controlKey) != 0 { s += "⌃" }
        if carbonModifiers & UInt32(optionKey)  != 0 { s += "⌥" }
        if carbonModifiers & UInt32(shiftKey)   != 0 { s += "⇧" }
        if carbonModifiers & UInt32(cmdKey)     != 0 { s += "⌘" }
        s += KeyCodeMap.name(for: keyCode)
        return s
    }

    func save() {
        let d = UserDefaults.standard
        d.set(Int(keyCode), forKey: "hotkey.keyCode")
        d.set(Int(carbonModifiers), forKey: "hotkey.mods")
    }

    static func load() -> HotkeyCombo {
        let d = UserDefaults.standard
        guard d.object(forKey: "hotkey.keyCode") != nil else { return .default }
        return HotkeyCombo(
            keyCode: UInt32(d.integer(forKey: "hotkey.keyCode")),
            carbonModifiers: UInt32(d.integer(forKey: "hotkey.mods"))
        )
    }

    /// Build a combo from a recorded key event. Requires at least one modifier.
    static func from(event: NSEvent) -> HotkeyCombo? {
        var mods: UInt32 = 0
        let f = event.modifierFlags
        if f.contains(.command) { mods |= UInt32(cmdKey) }
        if f.contains(.option)  { mods |= UInt32(optionKey) }
        if f.contains(.control) { mods |= UInt32(controlKey) }
        if f.contains(.shift)   { mods |= UInt32(shiftKey) }
        guard mods != 0 else { return nil }
        return HotkeyCombo(keyCode: UInt32(event.keyCode), carbonModifiers: mods)
    }
}

/// Registers a single global hotkey using the Carbon Hot Key API.
final class HotkeyManager {
    private var hotKeyRef: EventHotKeyRef?
    private var handlerRef: EventHandlerRef?
    private let action: () -> Void

    /// The Carbon hot-key callback is a bare C function pointer and cannot capture
    /// context, so the active manager is reachable through this static reference.
    private static weak var active: HotkeyManager?

    init(action: @escaping () -> Void) {
        self.action = action
        HotkeyManager.active = self
        installHandler()
    }

    private func installHandler() {
        var spec = EventTypeSpec(
            eventClass: OSType(kEventClassKeyboard),
            eventKind: UInt32(kEventHotKeyPressed)
        )
        InstallEventHandler(
            GetApplicationEventTarget(),
            { _, _, _ -> OSStatus in
                HotkeyManager.active?.action()
                return noErr
            },
            1, &spec, nil, &handlerRef
        )
    }

    func register(_ combo: HotkeyCombo) {
        unregister()
        var ref: EventHotKeyRef?
        let id = EventHotKeyID(signature: OSType(0x494D5052), id: 1) // 'IMPR'
        let status = RegisterEventHotKey(
            combo.keyCode, combo.carbonModifiers, id,
            GetApplicationEventTarget(), 0, &ref
        )
        if status == noErr { hotKeyRef = ref }
    }

    func unregister() {
        if let ref = hotKeyRef {
            UnregisterEventHotKey(ref)
            hotKeyRef = nil
        }
    }
}

/// Maps common virtual key codes to their display glyphs.
enum KeyCodeMap {
    private static let table: [UInt32: String] = [
        UInt32(kVK_ANSI_A): "A", UInt32(kVK_ANSI_B): "B", UInt32(kVK_ANSI_C): "C",
        UInt32(kVK_ANSI_D): "D", UInt32(kVK_ANSI_E): "E", UInt32(kVK_ANSI_F): "F",
        UInt32(kVK_ANSI_G): "G", UInt32(kVK_ANSI_H): "H", UInt32(kVK_ANSI_I): "I",
        UInt32(kVK_ANSI_J): "J", UInt32(kVK_ANSI_K): "K", UInt32(kVK_ANSI_L): "L",
        UInt32(kVK_ANSI_M): "M", UInt32(kVK_ANSI_N): "N", UInt32(kVK_ANSI_O): "O",
        UInt32(kVK_ANSI_P): "P", UInt32(kVK_ANSI_Q): "Q", UInt32(kVK_ANSI_R): "R",
        UInt32(kVK_ANSI_S): "S", UInt32(kVK_ANSI_T): "T", UInt32(kVK_ANSI_U): "U",
        UInt32(kVK_ANSI_V): "V", UInt32(kVK_ANSI_W): "W", UInt32(kVK_ANSI_X): "X",
        UInt32(kVK_ANSI_Y): "Y", UInt32(kVK_ANSI_Z): "Z",
        UInt32(kVK_ANSI_0): "0", UInt32(kVK_ANSI_1): "1", UInt32(kVK_ANSI_2): "2",
        UInt32(kVK_ANSI_3): "3", UInt32(kVK_ANSI_4): "4", UInt32(kVK_ANSI_5): "5",
        UInt32(kVK_ANSI_6): "6", UInt32(kVK_ANSI_7): "7", UInt32(kVK_ANSI_8): "8",
        UInt32(kVK_ANSI_9): "9",
        UInt32(kVK_Space): "Space", UInt32(kVK_Return): "↩", UInt32(kVK_Tab): "⇥",
        UInt32(kVK_Escape): "⎋", UInt32(kVK_Delete): "⌫",
        UInt32(kVK_ANSI_Period): ".", UInt32(kVK_ANSI_Comma): ",", UInt32(kVK_ANSI_Slash): "/",
        UInt32(kVK_F1): "F1", UInt32(kVK_F2): "F2", UInt32(kVK_F3): "F3", UInt32(kVK_F4): "F4",
        UInt32(kVK_F5): "F5", UInt32(kVK_F6): "F6", UInt32(kVK_F7): "F7", UInt32(kVK_F8): "F8"
    ]

    static func name(for keyCode: UInt32) -> String {
        table[keyCode] ?? "Key\(keyCode)"
    }
}
