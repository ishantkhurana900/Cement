import SwiftUI
import AppKit

@main
struct ImprovApp: App {
    @NSApplicationDelegateAdaptor(AppDelegate.self) private var appDelegate

    var body: some Scene {
        MenuBarExtra("Improv", systemImage: "wand.and.stars") {
            MenuBarView()
                .environmentObject(appDelegate.state)
        }
        .menuBarExtraStyle(.menu)

        Settings {
            SettingsView()
                .environmentObject(appDelegate.state)
        }
    }
}

@MainActor
final class AppDelegate: NSObject, NSApplicationDelegate {
    let state = AppState()
    private var hotkey: HotkeyManager?

    func applicationDidFinishLaunching(_ notification: Notification) {
        // Menu-bar only app.
        NSApp.setActivationPolicy(.accessory)

        // Ask for Accessibility permission up front (needed for copy/paste automation).
        _ = AccessibilityPermission.promptIfNeeded()

        // Register the global hotkey and wire it to the improve flow.
        hotkey = HotkeyManager { [weak self] in
            self?.state.improveSelection()
        }
        hotkey?.register(state.hotkey)

        // Re-register when the user changes the shortcut in Settings.
        state.onHotkeyChange = { [weak self] combo in
            self?.hotkey?.register(combo)
        }
    }
}
