import SwiftUI
import AppKit

/// Writing tone applied to the rewrite.
enum Tone: String, CaseIterable, Identifiable {
    case professional = "Professional"
    case casual = "Casual"
    case concise = "Concise"
    case friendly = "Friendly"

    var id: String { rawValue }

    /// Extra instruction appended to the system prompt.
    var instruction: String {
        switch self {
        case .professional: return "Use a polished, professional tone suitable for work email."
        case .casual:       return "Use a relaxed, natural, conversational tone."
        case .concise:      return "Be as concise as possible while keeping all key information."
        case .friendly:     return "Use a warm, friendly, approachable tone."
        }
    }
}

/// Central app state + orchestration of the improve flow.
@MainActor
final class AppState: ObservableObject {
    // MARK: Persisted settings
    @Published var baseURL: String {
        didSet { UserDefaults.standard.set(baseURL, forKey: "baseURL") }
    }
    @Published var model: String {
        didSet { UserDefaults.standard.set(model, forKey: "model") }
    }
    @Published var tone: Tone {
        didSet { UserDefaults.standard.set(tone.rawValue, forKey: "tone") }
    }
    @Published var hotkey: HotkeyCombo {
        didSet {
            hotkey.save()
            onHotkeyChange?(hotkey)
        }
    }

    /// API key lives in the Keychain, mirrored here for the Settings field.
    @Published var apiKey: String {
        didSet { Keychain.set(apiKey, for: "apiKey") }
    }

    // MARK: Runtime
    @Published var lastError: String?
    var onHotkeyChange: ((HotkeyCombo) -> Void)?

    private let preview = PreviewWindowController()

    init() {
        let d = UserDefaults.standard
        self.baseURL = d.string(forKey: "baseURL") ?? "https://api.openai.com/v1"
        self.model = d.string(forKey: "model") ?? "gpt-4o-mini"
        self.tone = Tone(rawValue: d.string(forKey: "tone") ?? "") ?? .professional
        self.hotkey = HotkeyCombo.load()
        self.apiKey = Keychain.get("apiKey") ?? ""
    }

    // MARK: Improve flow

    /// Entry point triggered by the hotkey or the menu item.
    func improveSelection() {
        guard AccessibilityPermission.isTrusted else {
            AccessibilityPermission.showDeniedAlert()
            return
        }

        guard let original = TextCapture.captureSelection(), !original.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else {
            NSSound.beep()
            return
        }

        guard !apiKey.isEmpty else {
            preview.showError("No API key set. Open Improv → Settings and add your API key.", original: original)
            return
        }

        preview.showLoading(original: original,
                            onAccept: { [weak self] finalText in
                                self?.preview.close()
                                TextCapture.replaceSelection(with: finalText)
                            },
                            onCancel: { [weak self] in
                                self?.preview.close()
                            },
                            onRegenerate: { [weak self] in
                                self?.runImprovement(original)
                            })

        runImprovement(original)
    }

    private func runImprovement(_ original: String) {
        preview.setImproving()
        let client = AIClient(baseURL: baseURL, apiKey: apiKey, model: model)
        let toneInstruction = tone.instruction
        Task { @MainActor in
            do {
                let improved = try await client.improve(text: original, toneInstruction: toneInstruction)
                preview.setResult(improved)
            } catch {
                preview.setErrorMessage(Self.describe(error))
            }
        }
    }

    static func describe(_ error: Error) -> String {
        if let e = error as? AIError { return e.message }
        return error.localizedDescription
    }
}
