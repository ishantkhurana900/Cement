import SwiftUI
import AppKit

struct MenuBarView: View {
    @EnvironmentObject var state: AppState

    var body: some View {
        Button("Improve Selection  (\(state.hotkey.displayString))") {
            state.improveSelection()
        }

        Divider()

        if !AccessibilityPermission.isTrusted {
            Button("⚠️ Grant Accessibility Permission…") {
                AccessibilityPermission.openSettings()
            }
            Divider()
        }

        SettingsLink {
            Text("Settings…")
        }
        .keyboardShortcut(",", modifiers: .command)

        Divider()

        Button("Quit Improv") {
            NSApp.terminate(nil)
        }
        .keyboardShortcut("q", modifiers: .command)
    }
}
