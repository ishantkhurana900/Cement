import SwiftUI
import AppKit

@MainActor
final class PreviewModel: ObservableObject {
    enum Phase {
        case improving
        case result
        case error
    }

    @Published var phase: Phase = .improving
    @Published var original: String = ""
    @Published var improved: String = ""
    @Published var errorMessage: String = ""

    var onAccept: ((String) -> Void)?
    var onCancel: (() -> Void)?
    var onRegenerate: (() -> Void)?
}

/// Owns the floating preview panel and drives its state through the improve flow.
@MainActor
final class PreviewWindowController {
    private var window: NSWindow?
    let model = PreviewModel()

    func showLoading(original: String,
                     onAccept: @escaping (String) -> Void,
                     onCancel: @escaping () -> Void,
                     onRegenerate: @escaping () -> Void) {
        model.original = original
        model.improved = ""
        model.errorMessage = ""
        model.phase = .improving
        model.onAccept = onAccept
        model.onCancel = onCancel
        model.onRegenerate = onRegenerate
        present()
    }

    func setImproving() {
        model.phase = .improving
    }

    func setResult(_ improved: String) {
        model.improved = improved
        model.phase = .result
    }

    func setErrorMessage(_ message: String) {
        model.errorMessage = message
        model.phase = .error
    }

    /// Used when we can't even start (e.g. no API key configured).
    func showError(_ message: String, original: String) {
        model.original = original
        model.errorMessage = message
        model.phase = .error
        model.onCancel = { [weak self] in self?.close() }
        model.onAccept = nil
        model.onRegenerate = nil
        present()
    }

    func close() {
        window?.orderOut(nil)
    }

    private func present() {
        if window == nil {
            let hosting = NSHostingController(rootView: PreviewView(model: model))
            let win = NSWindow(contentViewController: hosting)
            win.title = "Improv"
            win.styleMask = [.titled, .closable, .fullSizeContentView]
            win.titlebarAppearsTransparent = true
            win.isReleasedWhenClosed = false
            win.level = .floating
            win.setContentSize(NSSize(width: 520, height: 460))
            window = win
        }
        window?.center()
        NSApp.activate(ignoringOtherApps: true)
        window?.makeKeyAndOrderFront(nil)
    }
}

struct PreviewView: View {
    @ObservedObject var model: PreviewModel

    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("Improve Text")
                .font(.headline)

            switch model.phase {
            case .improving:
                improvingBody
            case .result:
                resultBody
            case .error:
                errorBody
            }
        }
        .padding(20)
        .frame(minWidth: 520, minHeight: 460)
    }

    private var improvingBody: some View {
        VStack(spacing: 16) {
            Spacer()
            ProgressView("Improving…")
            Spacer()
            Button("Cancel") { model.onCancel?() }
                .keyboardShortcut(.cancelAction)
        }
        .frame(maxWidth: .infinity)
    }

    private var resultBody: some View {
        VStack(alignment: .leading, spacing: 10) {
            Text("Original")
                .font(.caption).foregroundColor(.secondary)
            ScrollView {
                Text(model.original)
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .textSelection(.enabled)
            }
            .frame(height: 90)
            .padding(8)
            .background(Color(nsColor: .textBackgroundColor).opacity(0.5))
            .cornerRadius(6)

            Text("Improved (editable)")
                .font(.caption).foregroundColor(.secondary)
            TextEditor(text: $model.improved)
                .font(.body)
                .padding(4)
                .background(Color(nsColor: .textBackgroundColor))
                .cornerRadius(6)
                .frame(minHeight: 150)

            HStack {
                Button("Regenerate") { model.onRegenerate?() }
                Spacer()
                Button("Cancel") { model.onCancel?() }
                    .keyboardShortcut(.cancelAction)
                Button("Accept & Replace") { model.onAccept?(model.improved) }
                    .keyboardShortcut(.defaultAction)
                    .disabled(model.improved.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
            }
        }
    }

    private var errorBody: some View {
        VStack(alignment: .leading, spacing: 16) {
            Spacer()
            Label(model.errorMessage, systemImage: "exclamationmark.triangle")
                .foregroundColor(.secondary)
                .frame(maxWidth: .infinity, alignment: .leading)
            Spacer()
            HStack {
                if model.onRegenerate != nil {
                    Button("Try Again") { model.onRegenerate?() }
                }
                Spacer()
                Button("Close") { model.onCancel?() }
                    .keyboardShortcut(.defaultAction)
            }
        }
        .frame(maxWidth: .infinity)
    }
}
