import Foundation

struct AIError: Error {
    let message: String
}

/// Calls an OpenAI-compatible /chat/completions endpoint to rewrite text.
struct AIClient {
    let baseURL: String
    let apiKey: String
    let model: String

    func improve(text: String, toneInstruction: String) async throws -> String {
        let system = """
        You are an expert editor. Improve the grammar, clarity, structure, and flow of the \
        user's text while preserving their original meaning and intent. \(toneInstruction) \
        Return ONLY the rewritten text, with no preamble, quotation marks, or explanation.
        """

        let body: [String: Any] = [
            "model": model,
            "temperature": 0.4,
            "messages": [
                ["role": "system", "content": system],
                ["role": "user", "content": text]
            ]
        ]

        guard let url = URL(string: trimmedBase + "/chat/completions") else {
            throw AIError(message: "Invalid API base URL.")
        }

        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.setValue("Bearer \(apiKey)", forHTTPHeaderField: "Authorization")
        request.httpBody = try JSONSerialization.data(withJSONObject: body)
        request.timeoutInterval = 60

        let (data, response): (Data, URLResponse)
        do {
            (data, response) = try await URLSession.shared.data(for: request)
        } catch {
            throw AIError(message: "Network error: \(error.localizedDescription)")
        }

        guard let http = response as? HTTPURLResponse else {
            throw AIError(message: "No response from server.")
        }

        guard (200..<300).contains(http.statusCode) else {
            throw AIError(message: serverMessage(from: data, status: http.statusCode))
        }

        guard
            let json = try? JSONSerialization.jsonObject(with: data) as? [String: Any],
            let choices = json["choices"] as? [[String: Any]],
            let message = choices.first?["message"] as? [String: Any],
            let content = message["content"] as? String
        else {
            throw AIError(message: "Unexpected response format from the API.")
        }

        return content.trimmingCharacters(in: .whitespacesAndNewlines)
    }

    private var trimmedBase: String {
        var b = baseURL.trimmingCharacters(in: .whitespaces)
        while b.hasSuffix("/") { b.removeLast() }
        return b
    }

    /// Extract a human-readable error message from an OpenAI-style error body.
    private func serverMessage(from data: Data, status: Int) -> String {
        if let json = try? JSONSerialization.jsonObject(with: data) as? [String: Any],
           let error = json["error"] as? [String: Any],
           let message = error["message"] as? String {
            return "API error (\(status)): \(message)"
        }
        if let text = String(data: data, encoding: .utf8), !text.isEmpty {
            return "API error (\(status)): \(text.prefix(200))"
        }
        return "API error (HTTP \(status))."
    }
}
