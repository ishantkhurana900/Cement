import SwiftUI
import AppKit

struct SettingsView: View {
    @EnvironmentObject var state: AppState

    var body: some View {
        Form {
            Section("AI Endpoint") {
                TextField("API Base URL", text: $state.baseURL)
                    .textFieldStyle(.roundedBorder)
                Text("OpenAI-compatible base, e.g. https://api.openai.com/v1")
                    .font(.caption).foregroundColor(.secondary)

                TextField("Model", text: $state.model)
                    .textFieldStyle(.roundedBorder)

                SecureField("API Key", text: $state.apiKey)
                    .textFieldStyle(.roundedBorder)
                Text("Stored securely in your macOS Keychain.")
                    .font(.caption).foregroundColor(.secondary)
            }

            Section("Rewrite Style") {
                Picker("Tone", selection: $state.tone) {
                    ForEach(Tone.allCases) { tone in
                        Text(tone.rawValue).tag(tone)
                    }
                }
                .pickerStyle(.menu)
            }

            Section("Shortcut") {
                HotkeyRecorder(combo: $state.hotkey)
                Text("Select text in any app, then press this shortcut to improve it.")
                    .font(.caption).foregroundColor(.secondary)
            }

            Section("Permissions") {
                HStack {
                    Image(systemName: AccessibilityPermission.isTrusted ? "checkmark.circle.fill" : "exclamationmark.triangle.fill")
                        .foregroundColor(AccessibilityPermission.isTrusted ? .green : .orange)
                    Text(AccessibilityPermission.isTrusted
                         ? "Accessibility access granted."
                         : "Accessibility access required for copy/paste.")
                    Spacer()
                    if !AccessibilityPermission.isTrusted {
                        Button("Open Settings") { AccessibilityPermission.openSettings() }
                    }
                }
            }
        }
        .formStyle(.grouped)
        .frame(width: 460, height: 520)
    }
}

/// A button that records a global hotkey combination from the next key press.
struct HotkeyRecorder: View {
    @Binding var combo: HotkeyCombo
    @State private var recording = false
    @State private var monitor: Any?

    var body: some View {
        HStack {
            Text("Improve Shortcut")
            Spacer()
            Text(combo.displayString)
                .font(.system(.body, design: .monospaced))
                .foregroundColor(.secondary)
            Button(recording ? "Press keys…" : "Change") {
                recording ? stop() : start()
            }
        }
    }

    private func start() {
        recording = true
        monitor = NSEvent.addLocalMonitorForEvents(matching: .keyDown) { event in
            if let c = HotkeyCombo.from(event: event) {
                combo = c
            }
            stop()
            return nil
        }
    }

    private func stop() {
        recording = false
        if let m = monitor {
            NSEvent.removeMonitor(m)
            monitor = nil
        }
    }
}
